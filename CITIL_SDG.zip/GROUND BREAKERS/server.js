require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const cron = require("node-cron");
const nodemailer = require("nodemailer");
const twilio = require("twilio");

const app = express();

const allowedOrigins = ["http://localhost:5500", "http://127.0.0.1:5500"];
app.use(cors({
    origin: function (origin, callback) {
        if (!origin || allowedOrigins.includes(origin)) {
            callback(null, true);
        } else {
            callback(new Error("Not allowed by CORS"));
        }
    },
    credentials: true,
}));

app.use(bodyParser.json());

const uri = process.env.MONGO_URI;

async function connectDB() {
    try {
        await mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        console.log("✅ MongoDB Connected");
    } catch (err) {
        console.error("❌ MongoDB Connection Error:", err.message);
        process.exit(1);
    }
}

mongoose.connection.on("error", (err) => {
    console.error("❌ MongoDB Error:", err);
});

connectDB();

const notificationSchema = new mongoose.Schema({
    dateTime: Date,
    message: String,
    whatsappNumbers: [String],
    emails: [String],
    sent: { type: Boolean, default: false }
});
const Notification = mongoose.model("Notification", notificationSchema);

const progressReportSchema = new mongoose.Schema({
    studentName: String,
    progress: String,
    riskLevel: String,
    parentEmail: String,
    studentEmail: String,
    sent: { type: Boolean, default: false }
});
const ProgressReport = mongoose.model("ProgressReport", progressReportSchema);

const hiringSchema = new mongoose.Schema({
    companyName: String,
    jobRole: String,
    deadline: Date,
    emails: [String],
    whatsappNumbers: [String],
    sent: { type: Boolean, default: false }
});
const Hiring = mongoose.model("Hiring", hiringSchema);

app.post("/api/schedule", async (req, res) => {
    try {
        const { dateTime, message, whatsappNumbers, emails } = req.body;
        if (!dateTime || !message) {
            return res.status(400).json({ success: false, message: "DateTime and message are required." });
        }
        const notification = new Notification({ dateTime, message, whatsappNumbers, emails });
        await notification.save();
        res.status(201).json({ success: true, message: "✅ Notification Scheduled!" });
    } catch (error) {
        console.error("❌ Error scheduling notification:", error);
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post("/api/progress-report", async (req, res) => {
    try {
        const { studentName, progress, riskLevel, parentEmail, studentEmail } = req.body;
        const report = new ProgressReport({ studentName, progress, riskLevel, parentEmail, studentEmail });
        await report.save();
        res.status(201).json({ success: true, message: "✅ Progress Report Saved!" });
    } catch (error) {
        console.error("❌ Error saving progress report:", error);
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post("/api/hiring", async (req, res) => {
    try {
        const { companyName, jobRole, deadline, emails, whatsappNumbers } = req.body;
        const hiring = new Hiring({ companyName, jobRole, deadline, emails, whatsappNumbers });
        await hiring.save();
        res.status(201).json({ success: true, message: "✅ Hiring Information Saved!" });
    } catch (error) {
        console.error("❌ Error saving hiring information:", error);
        res.status(500).json({ success: false, error: error.message });
    }
});

const sendEmail = async (email, subject, message) => {
    try {
        const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });

        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: subject,
            text: message
        };

        await transporter.sendMail(mailOptions);
        console.log(`✅ Email sent to ${email}`);
    } catch (error) {
        console.error(`❌ Failed to send email to ${email}:`, error.message);
    }
};

const sendWhatsAppMessage = async (number, message) => {
    const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH_TOKEN);
    await client.messages.create({
        body: message,
        from: 'whatsapp:+14155238886',
        to: `whatsapp:${number}`,
    });
    console.log(`✅ WhatsApp message sent to ${number}`);
};

cron.schedule("*/1 * * * *", async () => {
    try {
        const now = new Date();
        const notifications = await Notification.find({ dateTime: { $lte: now }, sent: false });
        for (const notification of notifications) {
            if (notification.emails.length > 0) {
                for (const email of notification.emails) {
                    await sendEmail(email, "Scheduled Notification", notification.message);
                }
            }
            if (notification.whatsappNumbers.length > 0) {
                for (const number of notification.whatsappNumbers) {
                    await sendWhatsAppMessage(number, notification.message);
                }
            }
            notification.sent = true;
            await notification.save();
        }

        const reports = await ProgressReport.find({ sent: false });
        for (const report of reports) {
            const message = `Progress Report for ${report.studentName}:\nProgress: ${report.progress}\nRisk Level: ${report.riskLevel}`;
            await sendEmail(report.parentEmail, "Student Progress Report", message);
            await sendEmail(report.studentEmail, "Your Progress Report", message);
            report.sent = true;
            await report.save();
        }

        const hirings = await Hiring.find({ deadline: { $lte: now }, sent: false });
        for (const hiring of hirings) {
            const message = `New Job Opportunity!\nCompany: ${hiring.companyName}\nRole: ${hiring.jobRole}\nDeadline: ${hiring.deadline}`;
            if (hiring.emails.length > 0) {
                for (const email of hiring.emails) {
                    await sendEmail(email, "New Job Opportunity", message);
                }
            }
            if (hiring.whatsappNumbers.length > 0) {
                for (const number of hiring.whatsappNumbers) {
                    await sendWhatsAppMessage(number, message);
                }
            }
            hiring.sent = true;
            await hiring.save();
        }
    } catch (error) {
        console.error("❌ Error in Cron Job:", error.message);
    }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));