document.getElementById("scheduleForm").addEventListener("submit", async function (event) {
    event.preventDefault();
    const dateTime = document.getElementById("dateTime").value;
    const message = document.getElementById("message").value;
    const whatsappNumbers = document.getElementById("whatsappNumbers").value.split(",").map(num => num.trim());
    const emails = document.getElementById("emails").value.split(",").map(email => email.trim());

    if (!dateTime || !message) {
        displayResponseMessage("Date & Time and Message are required!", "error");
        return;
    }

    const payload = { dateTime: new Date(dateTime), message, whatsappNumbers, emails };
    try {
        const response = await fetch("http://localhost:5000/api/schedule", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
        const data = await response.json();
        displayResponseMessage(data.success ? "✅ Notification Scheduled!" : "❌ Error: " + data.message, data.success ? "success" : "error");
    } catch (error) {
        console.error("Error:", error);
        displayResponseMessage("❌ Error: Unable to connect to the server.", "error");
    }
});

document.getElementById("progressReportForm").addEventListener("submit", async function (event) {
    event.preventDefault();
    const studentName = document.getElementById("studentName").value;
    const progress = document.getElementById("progress").value;
    const riskLevel = document.getElementById("riskLevel").value;
    const parentEmail = document.getElementById("parentEmail").value;
    const studentEmail = document.getElementById("studentEmail").value;

    const payload = { studentName, progress, riskLevel, parentEmail, studentEmail };
    try {
        const response = await fetch("http://localhost:5000/api/progress-report", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
        const data = await response.json();
        displayResponseMessage(data.success ? "✅ Progress Report Saved!" : "❌ Error: " + data.message, data.success ? "success" : "error");
    } catch (error) {
        console.error("Error:", error);
        displayResponseMessage("❌ Error: Unable to connect to the server.", "error");
    }
});

document.getElementById("hiringForm").addEventListener("submit", async function (event) {
    event.preventDefault();
    const companyName = document.getElementById("companyName").value;
    const jobRole = document.getElementById("jobRole").value;
    const deadline = document.getElementById("deadline").value;
    const emails = document.getElementById("hiringEmails").value.split(",").map(email => email.trim());
    const whatsappNumbers = document.getElementById("hiringWhatsappNumbers").value.split(",").map(num => num.trim());

    const payload = { companyName, jobRole, deadline: new Date(deadline), emails, whatsappNumbers };
    try {
        const response = await fetch("http://localhost:5000/api/hiring", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
        const data = await response.json();
        displayResponseMessage(data.success ? "✅ Hiring Information Saved!" : "❌ Error: " + data.message, data.success ? "success" : "error");
    } catch (error) {
        console.error("Error:", error);
        displayResponseMessage("❌ Error: Unable to connect to the server.", "error");
    }
});

function displayResponseMessage(message, type) {
    const responseMessage = document.getElementById("responseMessage");
    responseMessage.textContent = message;
    responseMessage.style.color = type === "success" ? "green" : "red";
}